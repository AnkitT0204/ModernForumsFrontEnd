// import { useEffect, useState } from 'react';
// import { useSelector, useDispatch } from 'react-redux';
// import { useParams, Link } from 'react-router-dom';
// import api from '../utils/api';
// import PostForm from './PostForm';
// import { addNewPost, addDeletedPost, clearNewPosts, clearDeletedPosts, connectSocket } from '../store/socketSlice';

// function PostsPage() {
//   const { threadId } = useParams();
//   const [thread, setThread] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const { user, role } = useSelector((state) => state.auth);
//   const { socket, newPosts, deletedPosts, isConnected } = useSelector((state) => state.socket);
//   const dispatch = useDispatch();

//   useEffect(() => {
//     if (!isConnected) {
//       dispatch(connectSocket());
//     }
//     socket.emit('joinThread', threadId);
//     socket.on('newPost', (post) => {
//       console.log('Received newPost:', post);
//       if (post.thread === threadId) {
//         dispatch(addNewPost(post));
//       }
//     });
//     socket.on('postDeleted', (postId) => {
//       console.log('Received postDeleted:', postId);
//       dispatch(addDeletedPost(postId));
//     });

//     return () => {
//       socket.off('newPost');
//       socket.off('postDeleted');
//     };
//   }, [socket, threadId, dispatch, isConnected]);

//   useEffect(() => {
//     api
//       .get(`/threads/${threadId}`)
//       .then((response) => {
//         setThread(response.data);
//         setLoading(false);
//       })
//       .catch((err) => {
//         setError(err.response?.data?.error || 'Failed to fetch thread');
//         setLoading(false);
//       });
//   }, [threadId]);

//   useEffect(() => {
//     if (newPosts.length > 0) {
//       setThread((prev) => {
//         if (!prev) return prev;
//         const updatedPosts = [...prev.posts, ...newPosts.filter((post) => post.thread === threadId)];
//         return { ...prev, posts: updatedPosts };
//       });
//       dispatch(clearNewPosts());
//     }
//   }, [newPosts, threadId, dispatch]);

//   useEffect(() => {
//     if (deletedPosts.length > 0) {
//       setThread((prev) => {
//         if (!prev) return prev;
//         const updatedPosts = prev.posts.filter((post) => !deletedPosts.includes(post._id));
//         return { ...prev, posts: updatedPosts };
//       });
//       dispatch(clearDeletedPosts());
//     }
//   }, [deletedPosts, dispatch]);

//   if (loading) {
//     return (
//       <div className="flex justify-center items-center min-h-[400px]">
//         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[var(--accent-primary)]"></div>
//       </div>
//     );
//   }
  
//   if (error) {
//     return (
//       <div className="text-center text-[var(--danger)] p-8 card">
//         <svg className="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
//         </svg>
//         <p className="text-xl font-semibold">{error}</p>
//       </div>
//     );
//   }
  
//   if (!thread) {
//     return (
//       <div className="text-center text-[var(--text-secondary)] p-8 card">
//         <p className="text-xl font-semibold">Thread not found</p>
//       </div>
//     );
//   }

//   const originalPost = thread.posts[0];
//   const replies = thread.posts.slice(1);

//   return (
//     <div>
//       {/* Thread Header */}
//       <div className="mb-8">
//         <h1 className="text-3xl font-bold">{thread.title}</h1>
//         <div className="h-1 w-20 bg-[var(--accent-primary)] mt-2 mb-4 rounded-full"></div>
//       </div>
      
//       {/* Original Post */}
//       {originalPost && (
//         <div className="card p-6 mb-6">
//           <div className="flex items-center justify-between mb-3">
//             <div className="flex items-center">
//               <div className="h-10 w-10 rounded-full bg-[var(--accent-primary)] bg-opacity-10 flex items-center justify-center text-[var(--accent-primary)] font-bold">
//                 {originalPost.displayUsername.charAt(0).toUpperCase()}
//               </div>
//               <div className="ml-3">
//                 <p className="font-semibold">{originalPost.displayUsername}</p>
//                 <p className="text-xs text-[var(--text-secondary)]">
//                   {new Date(originalPost.createdAt).toLocaleDateString('en-US', { 
//                     month: 'short', 
//                     day: 'numeric', 
//                     year: 'numeric',
//                     hour: '2-digit', 
//                     minute: '2-digit'
//                   })}
//                 </p>
//               </div>
//             </div>
//             {(role === 'admin' || (role === 'moderator' && user.moderatorBoards?.includes(thread.board))) && (
//               <button
//                 onClick={async () => {
//                   try {
//                     await api.delete(`/posts/${originalPost._id}`);
//                   } catch (err) {
//                     console.error('Failed to delete post:', err);
//                   }
//                 }}
//                 className="text-[var(--danger)] hover:underline text-sm flex items-center"
//               >
//                 <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
//                 </svg>
//                 Delete
//               </button>
//             )}
//           </div>
//           <div className="post-content mt-4 text-lg leading-relaxed">
//             {originalPost.content}
//           </div>
//           {originalPost.media && (
//             <div className="mt-4 rounded-xl overflow-hidden">
//               <img
//                 src={`http://localhost:5001${originalPost.media}`}
//                 alt="Original post media"
//                 className="w-full max-h-96 object-contain"
//               />
//             </div>
//           )}
//         </div>
//       )}
      
//       {/* Comment Form */}
//       {user ? (
//         <PostForm threadId={threadId} />
//       ) : (
//         <div className="card p-6 mb-8 bg-[var(--bg-primary)] border border-[var(--card-border)] border-dashed">
//           <p className="text-center text-[var(--text-secondary)]">
//             Please <Link to="/login" className="text-[var(--accent-primary)] font-medium">login</Link> to add a comment.
//           </p>
//         </div>
//       )}
      
//       {/* Comments Section */}
//       <div className="mb-6">
//         <div className="flex items-center justify-between">
//           <h2 className="text-xl font-semibold">Comments ({replies.length})</h2>
//           <div className="h-[1px] flex-grow ml-4 bg-[var(--text-secondary)] opacity-10"></div>
//         </div>
//       </div>
      
//       {replies.length === 0 ? (
//         <div className="text-center py-12">
//           <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--bg-secondary)] flex items-center justify-center">
//             <svg className="w-8 h-8 text-[var(--text-secondary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
//             </svg>
//           </div>
//           <p className="text-[var(--text-secondary)]">No comments yet. Be the first to comment!</p>
//         </div>
//       ) : (
//         <div className="space-y-6">
//           {replies.map((post) => (
//             <div key={post._id} className="card p-6">
//               <div className="flex items-center justify-between mb-3">
//                 <div className="flex items-center">
//                   <div className="h-8 w-8 rounded-full bg-[var(--accent-primary)] bg-opacity-10 flex items-center justify-center text-[var(--accent-primary)] font-bold text-sm">
//                     {post.displayUsername.charAt(0).toUpperCase()}
//                   </div>
//                   <div className="ml-3">
//                     <p className="font-medium">{post.displayUsername}</p>
//                     <p className="text-xs text-[var(--text-secondary)]">
//                       {new Date(post.createdAt).toLocaleDateString('en-US', { 
//                         month: 'short', 
//                         day: 'numeric', 
//                         hour: '2-digit', 
//                         minute: '2-digit'
//                       })}
//                     </p>
//                   </div>
//                 </div>
//                 {(role === 'admin' || (role === 'moderator' && user.moderatorBoards?.includes(thread.board))) && (
//                   <button
//                     onClick={async () => {
//                       try {
//                         await api.delete(`/posts/${post._id}`);
//                       } catch (err) {
//                         console.error('Failed to delete post:', err);
//                       }
//                     }}
//                     className="text-[var(--danger)] hover:underline text-sm flex items-center"
//                   >
//                     <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
//                     </svg>
//                     Delete
//                   </button>
//                 )}
//               </div>
//               <div className="post-content mt-3">
//                 {post.content}
//               </div>
//               {post.media && (
//                 <div className="mt-4 rounded-xl overflow-hidden">
//                   <img
//                     src={`http://localhost:5001${post.media}`}
//                     alt="Comment media"
//                     className="max-w-full h-auto"
//                   />
//                 </div>
//               )}
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }

// export default PostsPage;



import { useEffect, useState, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import PostForm from './PostForm';
import { addNewPost, addDeletedPost, clearNewPosts, clearDeletedPosts, connectSocket } from '../store/socketSlice';
import gsap from 'gsap';

function PostsPage() {
  const { threadId } = useParams();
  const [thread, setThread] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user, role } = useSelector((state) => state.auth);
  const { socket, newPosts, deletedPosts, isConnected } = useSelector((state) => state.socket);
  const dispatch = useDispatch();
  
  const containerRef = useRef(null);
  const titleRef = useRef(null);
  const originalPostRef = useRef(null);
  const commentsRef = useRef(null);
  const tlRef = useRef(null);

  useEffect(() => {
    if (!isConnected) {
      dispatch(connectSocket());
    }
    socket.emit('joinThread', threadId);
    socket.on('newPost', (post) => {
      console.log('Received newPost:', post);
      if (post.thread === threadId) {
        dispatch(addNewPost(post));
        // Animate new post with GSAP
        gsap.fromTo(
          `.post-${post._id}`,
          { opacity: 0, y: 20, scale: 0.95 },
          { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: "back.out(1.7)" }
        );
      }
    });
    socket.on('postDeleted', (postId) => {
      console.log('Received postDeleted:', postId);
      dispatch(addDeletedPost(postId));
      // Animate post deletion
      gsap.to(
        `.post-${postId}`,
        { opacity: 0, y: -10, height: 0, marginBottom: 0, duration: 0.5, ease: "power3.out" }
      );
    });

    return () => {
      socket.off('newPost');
      socket.off('postDeleted');
    };
  }, [socket, threadId, dispatch, isConnected]);

  useEffect(() => {
    api
      .get(`/threads/${threadId}`)
      .then((response) => {
        setThread(response.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.response?.data?.error || 'Failed to fetch thread');
        setLoading(false);
      });
  }, [threadId]);

  useEffect(() => {
    if (newPosts.length > 0) {
      setThread((prev) => {
        if (!prev) return prev;
        const updatedPosts = [...prev.posts, ...newPosts.filter((post) => post.thread === threadId)];
        return { ...prev, posts: updatedPosts };
      });
      dispatch(clearNewPosts());
    }
  }, [newPosts, threadId, dispatch]);

  useEffect(() => {
    if (deletedPosts.length > 0) {
      setThread((prev) => {
        if (!prev) return prev;
        const updatedPosts = prev.posts.filter((post) => !deletedPosts.includes(post._id));
        return { ...prev, posts: updatedPosts };
      });
      dispatch(clearDeletedPosts());
    }
  }, [deletedPosts, dispatch]);
  
  // GSAP animations when content loads
  useEffect(() => {
    if (!loading && thread) {
      // Create timeline
      tlRef.current = gsap.timeline();
      
      // Animate title
      tlRef.current.from(titleRef.current, {
        opacity: 0,
        y: -20,
        duration: 0.6,
        ease: "power3.out"
      });
      
      // Animate original post
      tlRef.current.from(originalPostRef.current, {
        opacity: 0,
        y: 30,
        duration: 0.7,
        ease: "power3.out"
      }, "-=0.3");
      
      // Animate post form if user is logged in
      if (user) {
        tlRef.current.from(".post-form", {
          opacity: 0,
          y: 30,
          duration: 0.7,
          ease: "power3.out"
        }, "-=0.4");
      }
      
      // Animate comments header
      tlRef.current.from(".comments-header", {
        opacity: 0,
        y: 20,
        duration: 0.5,
        ease: "power3.out"
      }, "-=0.3");
      
      // Staggered animation for comments
      if (commentsRef.current && commentsRef.current.children.length > 0) {
        tlRef.current.from(commentsRef.current.children, {
          opacity: 0,
          y: 40,
          stagger: 0.1,
          duration: 0.6,
          ease: "power3.out"
        }, "-=0.2");
      }
    }
  }, [loading, thread, user]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-pulse flex space-x-2">
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full"></div>
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full animation-delay-200"></div>
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full animation-delay-400"></div>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center text-red-500 p-8 bg-red-50 rounded-lg">
        <svg className="w-10 h-10 mx-auto mb-4" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
        </svg>
        <h2 className="text-xl font-semibold mb-2">{error}</h2>
        <p>Please try refreshing the page.</p>
      </div>
    );
  }
  
  if (!thread) return <div className="text-center">Thread not found</div>;

  const originalPost = thread.posts[0];
  const replies = thread.posts.slice(1);

  return (
    <div ref={containerRef} className="py-8">
      <h1 ref={titleRef} className="text-4xl font-bold mb-6 tracking-tight">
        {thread.title}
      </h1>
      
      {originalPost && (
        <div ref={originalPostRef} className="card p-6 mb-8 border-l-4 border-l-[var(--accent-primary)]">
          <div className="flex items-center justify-between mb-4">
            <p className="flex items-center">
              <span className="inline-block w-8 h-8 rounded-full bg-[var(--accent-primary)] bg-opacity-10 text-[var(--accent-primary)] flex items-center justify-center mr-3 font-medium">
                {originalPost.displayUsername.charAt(0).toUpperCase()}
              </span>
              <span className="font-medium">{originalPost.displayUsername}</span>
              <span className="mx-2 text-[var(--text-primary)] opacity-30">•</span>
              <span className="text-[var(--text-primary)] opacity-60 text-sm">
                {new Date(originalPost.createdAt).toLocaleString()}
              </span>
            </p>
            
            {(role === 'admin' || (role === 'moderator' && user?.moderatorBoards?.includes(thread.board))) && (
              <button
                onClick={async () => {
                  try {
                    await api.delete(`/posts/${originalPost._id}`);
                    // Animation handled by socket event
                  } catch (err) {
                    console.error('Failed to delete post:', err);
                  }
                }}
                className="text-red-500 hover:text-red-600 transition-colors duration-200 flex items-center"
              >
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                Delete
              </button>
            )}
          </div>
          
          <div className="mt-4 text-lg leading-relaxed">{originalPost.content}</div>
          
          {originalPost.media && (
            <div 
              className="mt-6 media-preview overflow-hidden rounded-xl hover:shadow-lg transition-shadow duration-300"
              onClick={(e) => {
                // Zoom effect on image click
                const img = e.currentTarget;
                gsap.fromTo(
                  img,
                  { scale: 1 },
                  { 
                    scale: 1.02, 
                    duration: 0.3, 
                    ease: "power2.out",
                    yoyo: true,
                    repeat: 1
                  }
                );
              }}
            >
              <img
                src={`http://localhost:5001${originalPost.media}`}
                alt="Original post media"
                className="w-full h-auto transform transition-transform duration-500 hover:scale-105"
              />
            </div>
          )}
        </div>
      )}
      
      {user ? (
        <div className="post-form">
          <PostForm threadId={threadId} />
        </div>
      ) : (
        <div className="card p-6 mb-8 bg-gradient-to-r from-[var(--bg-secondary)] to-[var(--bg-primary)]">
          <p className="text-[var(--text-primary)] opacity-80 flex items-center">
            <svg className="w-5 h-5 mr-2 text-[var(--accent-primary)]" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
            Please <Link to="/login" className="text-[var(--accent-primary)] font-medium hover:underline mx-1">login</Link> to comment.
          </p>
        </div>
      )}
      
      <h2 className="text-2xl font-semibold mb-6 comments-header">
        <span className="text-[var(--accent-primary)]">{replies.length}</span> Comments
      </h2>
      
      {replies.length === 0 ? (
        <div className="card p-8 text-center bg-[var(--bg-secondary)] bg-opacity-50">
          <svg className="w-12 h-12 mx-auto mb-4 text-[var(--text-primary)] opacity-20" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clipRule="evenodd" />
          </svg>
          <p className="text-[var(--text-primary)] opacity-70 text-lg">No comments yet. Be the first to comment!</p>
        </div>
      ) : (
        <div ref={commentsRef} className="space-y-6">
          {replies.map((post) => (
            <div 
              key={post._id} 
              className={`card p-6 post-${post._id} hover:shadow-md transition-all duration-300`}
            >
              <div className="flex items-center justify-between mb-3">
                <p className="flex items-center">
                  <span className="inline-block w-7 h-7 rounded-full bg-[var(--accent-primary)] bg-opacity-10 text-[var(--accent-primary)] flex items-center justify-center mr-2 text-sm font-medium">
                    {post.displayUsername.charAt(0).toUpperCase()}
                  </span>
                  <span className="font-medium">{post.displayUsername}</span>
                  <span className="mx-2 text-[var(--text-primary)] opacity-30">•</span>
                  <span className="text-[var(--text-primary)] opacity-60 text-sm">
                    {new Date(post.createdAt).toLocaleString()}
                  </span>
                </p>
                
                {(role === 'admin' || (role === 'moderator' && user?.moderatorBoards?.includes(thread.board))) && (
                  <button
                    onClick={async () => {
                      try {
                        await api.delete(`/posts/${post._id}`);
                      } catch (err) {
                        console.error('Failed to delete post:', err);
                      }
                    }}
                    className="text-red-500 hover:text-red-600 transition-colors duration-200 flex items-center text-sm"
                  >
                    <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    Delete
                  </button>
                )}
              </div>
              
              <div className="mt-2">{post.content}</div>
              
              {post.media && (
                <div 
                  className="mt-4 media-preview overflow-hidden rounded-lg"
                  onClick={(e) => {
                    // Zoom effect on image click
                    const img = e.currentTarget;
                    gsap.fromTo(
                      img,
                      { scale: 1 },
                      { 
                        scale: 1.02, 
                        duration: 0.3, 
                        ease: "power2.out",
                        yoyo: true,
                        repeat: 1
                      }
                    );
                  }}
                >
                  <img
                    src={`http://localhost:5001${post.media}`}
                    alt="Comment media"
                    className="w-full h-auto transform transition-transform duration-500 hover:scale-105"
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default PostsPage;