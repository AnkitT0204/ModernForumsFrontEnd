import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import ThreadForm from './ThreadForm';

function ThreadsPage() {
  const { boardId } = useParams();
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    api
      .get(`/boards/${boardId}/threads`)
      .then((response) => {
        setThreads(response.data.threads);
        setLoading(false);
      })
      .catch((err) => {
        setError('Failed to fetch threads');
        setLoading(false);
      });
  }, [boardId]);

  if (loading) return <div className="text-center">Loading...</div>;
  if (error) return <div className="text-center text-red-500">{error}</div>;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Threads</h1>
      {user ? (
        <ThreadForm />
      ) : (
        <p className="text-[var(--text-primary)] opacity-80 mb-6">
          Please <Link to="/login" className="text-[var(--accent-primary)] underline">login</Link> to create threads or comment.
        </p>
      )}
      <div className="space-y-4">
        {threads.map((thread) => (
          <Link
            key={thread._id}
            to={`/threads/${thread._id}`}
            className="card p-6 block"
          >
            <h2 className="text-xl font-semibold">{thread.title}</h2>
            <p className="text-[var(--text-primary)] opacity-80">{thread.posts[0]?.content.substring(0, 100)}...</p>
            {thread.posts[0]?.media && (
              <img
                src={`http://localhost:5001${thread.posts[0].media}`}
                alt="Thread preview"
                className="mt-4 max-w-xs h-auto rounded-xl"
              />
            )}
          </Link>
        ))}
      </div>
    </div>
  );
}

export default ThreadsPage;