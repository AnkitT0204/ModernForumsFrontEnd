// import { useEffect, useState } from 'react';
// import { useSelector } from 'react-redux';
// import { Link } from 'react-router-dom';
// import api from '../utils/api';

// function BoardsPage() {
//   const [boards, setBoards] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const { user } = useSelector((state) => state.auth);

//   useEffect(() => {
//     api
//       .get('/boards')
//       .then((response) => {
//         setBoards(response.data.boards);
//         setLoading(false);
//       })
//       .catch((err) => {
//         setError('Failed to fetch boards');
//         setLoading(false);
//       });
//   }, []);

//   if (loading) {
//     return (
//       <div className="flex justify-center items-center min-h-[400px]">
//         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[var(--accent-primary)]"></div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="text-center text-[var(--danger)] p-8 card">
//         <svg className="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
//         </svg>
//         <p className="text-xl font-semibold">{error}</p>
//       </div>
//     );
//   }

//   const getRandomGradient = () => {
//     const gradients = [
//       'from-blue-500 to-indigo-600',
//       'from-green-500 to-teal-600',
//       'from-purple-500 to-pink-600',
//       'from-yellow-500 to-orange-600',
//       'from-red-500 to-pink-600',
//       'from-cyan-500 to-blue-600',
//     ];
//     return gradients[Math.floor(Math.random() * gradients.length)];
//   };

//   return (
//     <div>
//       <div className="mb-8">
//         <h1 className="text-3xl font-bold">Discussion Boards</h1>
//         <div className="h-1 w-20 bg-[var(--accent-primary)] mt-2 mb-4 rounded-full"></div>
//         <p className="text-[var(--text-secondary)]">
//           Join conversations on various topics and share your thoughts with the community.
//         </p>
//       </div>
      
//       {!user && (
//         <div className="card p-6 mb-8 bg-[var(--bg-primary)] border border-[var(--card-border)] border-dashed">
//           <div className="flex items-center">
//             <svg className="w-6 h-6 text-[var(--text-secondary)] mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
//             </svg>
//             <p className="text-[var(--text-secondary)]">
//               Please <Link to="/login" className="text-[var(--accent-primary)] font-medium">login</Link> to create threads or posts.
//             </p>
//           </div>
//         </div>
//       )}
      
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//         {boards.map((board, index) => (
//           <Link key={board._id} to={`/boards/${board._id}`} className="card overflow-hidden transition-all hover:transform hover:scale-[1.02]">
//             <div className={`h-3 bg-gradient-to-r ${getRandomGradient()}`}></div>
//             <div className="p-6">
//               <h2 className="text-xl font-semibold mb-2 flex items-center">
//                 <span className="text-[var(--accent-primary)]">/</span>
//                 {board.name}
//                 <span className="text-[var(--accent-primary)]">/</span>
//               </h2>
//               <p className="text-[var(--text-secondary)] mb-4">{board.description}</p>
//               <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
//                 <span>Active threads: {board.threadCount || 'N/A'}</span>
//                 <span className="flex items-center">
//                   <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z"></path>
//                   </svg>
//                   {board.postCount || 0} posts
//                 </span>
//               </div>
//             </div>
//           </Link>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default BoardsPage;


import { useEffect, useState, useRef } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import ThreadForm from './ThreadForm';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function BoardsPage() {
  const [boards, setBoards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useSelector((state) => state.auth);
  
  const headerRef = useRef(null);
  const boardsContainerRef = useRef(null);
  
  useEffect(() => {
    api
      .get('/boards')
      .then((response) => {
        setBoards(response.data.boards);
        setLoading(false);
      })
      .catch((err) => {
        setError('Failed to fetch boards');
        setLoading(false);
      });
  }, []);
  
  useEffect(() => {
    // Header animation
    gsap.from(headerRef.current, {
      opacity: 0,
      y: -20,
      duration: 0.8,
      ease: "power3.out"
    });
    
    // Board cards staggered animation
    if (!loading && boardsContainerRef.current) {
      gsap.from(boardsContainerRef.current.children, {
        opacity: 0,
        y: 40,
        duration: 0.8,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: {
          trigger: boardsContainerRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none"
        }
      });
    }
  }, [loading, boards]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-pulse flex space-x-2">
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full"></div>
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full animation-delay-200"></div>
          <div className="w-3 h-3 bg-[var(--accent-primary)] rounded-full animation-delay-400"></div>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center text-red-500 p-8 bg-red-50 rounded-lg">
        <svg className="w-10 h-10 mx-auto mb-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
        </svg>
        <h2 className="text-xl font-semibold mb-2">{error}</h2>
        <p>Please try refreshing the page or check your connection.</p>
      </div>
    );
  }

  return (
    <div className="py-8">
      <div ref={headerRef} className="mb-8">
        <h1 className="text-4xl font-bold mb-4 tracking-tight">
          <span className="text-[var(--accent-primary)]">Popular</span> Boards
        </h1>
        <p className="text-[var(--text-primary)] opacity-70 max-w-2xl">
          Join the conversation on our diverse range of boards covering everything from tech to arts and leisure.
        </p>
      </div>
      
      {user ? (
        <ThreadForm />
      ) : (
        <div className="card p-6 mb-8 bg-gradient-to-r from-[var(--bg-secondary)] to-[var(--bg-primary)] border border-opacity-10">
          <p className="text-[var(--text-primary)] opacity-80">
            <Link to="/login" className="text-[var(--accent-primary)] font-medium hover:underline">Login</Link> or <Link to="/register" className="text-[var(--accent-primary)] font-medium hover:underline">register</Link> to create threads and join discussions.
          </p>
        </div>
      )}
      
      <div 
        ref={boardsContainerRef}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {boards.map((board, index) => (
          <Link 
            key={board._id} 
            to={`/boards/${board._id}`}
            className="card group transform transition-all duration-300 hover:translate-y-0"
          >
            <div className="p-6">
              <div className="mb-3 flex items-center">
                <div className="w-10 h-10 rounded-lg bg-[var(--accent-primary)] bg-opacity-10 flex items-center justify-center text-[var(--accent-primary)] mr-3">
                  {board.name.charAt(0).toUpperCase()}
                </div>
                <h2 className="text-xl font-semibold group-hover:text-[var(--accent-primary)] transition-colors duration-200">/{board.name}/</h2>
              </div>
              <p className="text-[var(--text-primary)] opacity-70">{board.description}</p>
              <div className="mt-4 pt-4 border-t border-[var(--text-primary)] border-opacity-10 flex justify-between items-center">
                <span className="text-sm text-[var(--text-primary)] opacity-60">
                  {Math.floor(Math.random() * 50) + 10} threads
                </span>
                <span className="text-[var(--accent-primary)] font-medium text-sm flex items-center">
                  Browse
                  <svg className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-200" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default BoardsPage;