import { useState } from 'react';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import api from '../utils/api';

function ThreadForm() {
  const { boardId } = useParams();
  const { user } = useSelector((state) => state.auth);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [anonymous, setAnonymous] = useState(true);
  const [media, setMedia] = useState(null);
  const [mediaPreview, setMediaPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleMediaChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setMedia(file);
      const reader = new FileReader();
      reader.onload = () => {
        setMediaPreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setMedia(null);
      setMediaPreview(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('title', title);
    formData.append('content', content);
    formData.append('anonymous', anonymous);
    if (media) formData.append('media', media);

    try {
      await api.post(`/boards/${boardId}/threads`, formData);
      setTitle('');
      setContent('');
      setMedia(null);
      setMediaPreview(null);
      setAnonymous(true);
      // You could add a success message here
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create thread');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card mb-8">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold m-0">Create New Thread</h2>
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-[var(--success)] mr-2"></div>
            <span className="text-sm text-[var(--text-secondary)]">Posting as: {anonymous ? 'Anonymous' : user}</span>
          </div>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Thread title"
              className="w-full"
              required
            />
          </div>
          
          <div className="mb-4">
            <textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's on your mind?"
              className="w-full"
              rows="5"
              required
            ></textarea>
          </div>
          
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="media" className="text-sm font-medium text-[var(--text-secondary)]">
                Add an image (optional)
              </label>
              {media && (
                <button 
                  type="button"
                  onClick={() => {
                    setMedia(null);
                    setMediaPreview(null);
                  }}
                  className="text-xs text-[var(--danger)]"
                >
                  Remove
                </button>
              )}
            </div>
            
            {mediaPreview ? (
              <div className="relative mt-2 mb-4">
                <img 
                  src={mediaPreview} 
                  alt="Preview" 
                  className="w-full max-h-64 object-contain rounded-lg border border-[var(--input-border)]" 
                />
              </div>
            ) : (
              <div className="border-2 border-dashed border-[var(--input-border)] rounded-lg p-4 text-center cursor-pointer hover:border-[var(--accent-primary)] transition-colors">
                <input
                  type="file"
                  id="media"
                  accept="image/*"
                  onChange={handleMediaChange}
                  className="hidden"
                />
                <label htmlFor="media" className="cursor-pointer text-[var(--text-secondary)] block">
                  <svg className="w-8 h-8 mx-auto mb-2 text-[var(--text-secondary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path>
                  </svg>
                  Click to upload an image
                </label>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between mb-6">
            <label className="flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={anonymous}
                onChange={(e) => setAnonymous(e.target.checked)}
              />
              <span className="text-sm ml-2">Post anonymously</span>
            </label>
            
            {error && (
              <p className="text-[var(--danger)] text-sm">{error}</p>
            )}
          </div>
          
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="btn-primary"
            >
              {loading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating...
                </>
              ) : (
                'Create Thread'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ThreadForm;