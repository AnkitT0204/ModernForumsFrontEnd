// import { useState } from 'react';
// import { useSelector } from 'react-redux';
// import api from '../utils/api';

// function PostForm({ threadId }) {
//   const { user } = useSelector((state) => state.auth);
//   const [content, setContent] = useState('');
//   const [anonymous, setAnonymous] = useState(true);
//   const [media, setMedia] = useState(null);
//   const [mediaPreview, setMediaPreview] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [success, setSuccess] = useState(false);

//   const handleMediaChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       setMedia(file);
//       const reader = new FileReader();
//       reader.onload = () => {
//         setMediaPreview(reader.result);
//       };
//       reader.readAsDataURL(file);
//     } else {
//       setMedia(null);
//       setMediaPreview(null);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);
//     setError(null);
//     setSuccess(false);

//     const formData = new FormData();
//     formData.append('content', content);
//     formData.append('anonymous', anonymous);
//     if (media) formData.append('media', media);

//     try {
//       await api.post(`/threads/${threadId}/posts`, formData);
//       setContent('');
//       setMedia(null);
//       setMediaPreview(null);
//       setAnonymous(true);
//       setSuccess(true);
      
//       // Clear success message after 3 seconds
//       setTimeout(() => setSuccess(false), 3000);
//     } catch (err) {
//       setError(err.response?.data?.error || 'Failed to comment');
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="card p-6 mb-8">
//       <div className="flex items-center justify-between mb-4">
//         <h2 className="text-xl font-semibold m-0">Add a Comment</h2>
//         <div className="flex items-center">
//           <div className="h-2 w-2 rounded-full bg-[var(--success)] mr-2"></div>
//           <span className="text-sm text-[var(--text-secondary)]">
//             Posting as: {anonymous ? 'Anonymous' : user}
//           </span>
//         </div>
//       </div>
      
//       <form onSubmit={handleSubmit}>
//         <div className="mb-4">
//           <textarea
//             id="content"
//             value={content}
//             onChange={(e) => setContent(e.target.value)}
//             placeholder="Share your thoughts..."
//             className="w-full"
//             rows="4"
//             required
//           ></textarea>
//         </div>
        
//         <div className="mb-4">
//           <div className="flex items-center justify-between mb-2">
//             <label htmlFor="post-media" className="text-sm font-medium text-[var(--text-secondary)]">
//               Add an image (optional)
//             </label>
//             {media && (
//               <button 
//                 type="button"
//                 onClick={() => {
//                   setMedia(null);
//                   setMediaPreview(null);
//                 }}
//                 className="text-xs text-[var(--danger)]"
//               >
//                 Remove
//               </button>
//             )}
//           </div>
          
//           {mediaPreview ? (
//             <div className="relative mt-2 mb-4">
//               <img 
//                 src={mediaPreview} 
//                 alt="Preview" 
//                 className="w-full max-h-48 object-contain rounded-lg border border-[var(--input-border)]" 
//               />
//             </div>
//           ) : (
//             <div className="border-2 border-dashed border-[var(--input-border)] rounded-lg p-4 text-center cursor-pointer hover:border-[var(--accent-primary)] transition-colors">
//               <input
//                 type="file"
//                 id="post-media"
//                 accept="image/*"
//                 onChange={handleMediaChange}
//                 className="hidden"
//               />
//               <label htmlFor="post-media" className="cursor-pointer text-[var(--text-secondary)] block">
//                 <svg className="w-6 h-6 mx-auto mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
//                 </svg>
//                 Click to upload an image
//               </label>
//             </div>
//           )}
//         </div>
        
//         <div className="flex items-center justify-between mb-4">
//           <label className="flex items-center cursor-pointer">
//             <input
//               type="checkbox"
//               checked={anonymous}
//               onChange={(e) => setAnonymous(e.target.checked)}
//             />
//             <span className="text-sm ml-2">Comment anonymously</span>
//           </label>
          
//           {error && (
//             <p className="text-[var(--danger)] text-sm">{error}</p>
//           )}
          
//           {success && (
//             <p className="text-[var(--success)] text-sm flex items-center">
//               <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
//               </svg>
//               Comment posted successfully!
//             </p>
//           )}
//         </div>
        
//         <div className="flex justify-end">
//           <button
//             type="submit"
//             disabled={loading}
//             className="btn-primary"
//           >
//             {loading ? (
//               <>
//                 <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
//                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
//                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
//                 </svg>
//                 Posting...
//               </>
//             ) : (
//               'Post Comment'
//             )}
//           </button>
//         </div>
//       </form>
//     </div>
//   );
// }

// export default PostForm;

import { useState, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import api from '../utils/api';
import gsap from 'gsap';

function PostForm({ threadId }) {
  const { user } = useSelector((state) => state.auth);
  const [content, setContent] = useState('');
  const [anonymous, setAnonymous] = useState(true);
  const [media, setMedia] = useState(null);
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  // Refs for animation
  const formRef = useRef(null);
  const successRef = useRef(null);
  const contentInputRef = useRef(null);
  const fileInputRef = useRef(null);
  const previewRef = useRef(null);
  const btnRef = useRef(null);

  // Animate page mount
  useEffect(() => {
    gsap.fromTo(
      formRef.current,
      { opacity: 0, y: 64, scale: 0.98 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.8,
        ease: 'power3.out'
      }
    );
  }, []);

  // Animate input focus
  useEffect(() => {
    const input = contentInputRef.current;
    if (!input) return;
    const handleFocus = () => {
      gsap.to(input, {
        scale: 1.03,
        borderColor: 'rgba(0,255,153,0.7)',
        boxShadow: '0 2px 16px 0 rgba(0,255,153,0.07)',
        duration: 0.3,
        overwrite: true
      });
    };
    const handleBlur = () => {
      gsap.to(input, {
        scale: 1,
        borderColor: 'rgba(255,255,255,0.22)',
        boxShadow: '0 0px 0px 0 rgba(0,0,0,0)',
        duration: 0.3,
        overwrite: true
      });
    };
    input.addEventListener('focus', handleFocus);
    input.addEventListener('blur', handleBlur);
    return () => {
      input.removeEventListener('focus', handleFocus);
      input.removeEventListener('blur', handleBlur);
    };
  }, []);

  // Animate button hover
  useEffect(() => {
    const btn = btnRef.current;
    if (!btn) return;
    const handleEnter = () => {
      gsap.to(btn, { scale: 1.04, duration: 0.18, ease: 'power2.out' });
    };
    const handleLeave = () => {
      gsap.to(btn, { scale: 1, duration: 0.2, ease: 'power2.out' });
    };
    btn.addEventListener('mouseenter', handleEnter);
    btn.addEventListener('mouseleave', handleLeave);
    return () => {
      btn.removeEventListener('mouseenter', handleEnter);
      btn.removeEventListener('mouseleave', handleLeave);
    };
  }, []);

  // Handle image preview
  useEffect(() => {
    if (media) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(media);
    } else {
      setPreview(null);
    }
  }, [media]);

  // Animate preview appearance
  useEffect(() => {
    if (preview && previewRef.current) {
      gsap.fromTo(
        previewRef.current,
        { scale: 0.93, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, ease: 'power3.out' }
      );
    }
  }, [preview]);

  // Animate success message
  useEffect(() => {
    if (success && successRef.current) {
      gsap.fromTo(
        successRef.current,
        { opacity: 0, y: -16 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: 'power2.out',
          onComplete: () => {
            setTimeout(() => {
              if (successRef.current) {
                gsap.to(successRef.current, {
                  opacity: 0,
                  y: -16,
                  duration: 0.4,
                  onComplete: () => setSuccess(false)
                });
              }
            }, 2600);
          }
        }
      );
    }
  }, [success]);

  // Form shake on error
  const animateFormError = () => {
    gsap.fromTo(
      formRef.current,
      { x: 0 },
      {
        x: [-10, 10, -8, 8, -5, 5, 0],
        duration: 0.5,
        ease: 'power2.out'
      }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('content', content);
    formData.append('anonymous', anonymous);
    if (media) formData.append('media', media);

    try {
      await api.post(`/threads/${threadId}/posts`, formData);
      gsap.fromTo(
        formRef.current,
        { y: 0 },
        {
          y: 5,
          duration: 0.18,
          yoyo: true,
          repeat: 1,
          ease: 'power1.inOut',
          onComplete: () => {
            setContent('');
            setMedia(null);
            setPreview(null);
            setAnonymous(true);
            setSuccess(true);
          }
        }
      );
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to comment');
      animateFormError();
    } finally {
      setLoading(false);
    }
  };

  // Animate file input focus (bottom border)
  useEffect(() => {
    const fileInput = fileInputRef.current;
    if (!fileInput) return;
    const parent = fileInput.parentElement;
    const handleFocus = () => {
      gsap.to(parent, {
        borderColor: 'rgba(0,255,153,0.7)',
        duration: 0.3,
        overwrite: true
      });
    };
    const handleBlur = () => {
      gsap.to(parent, {
        borderColor: 'rgba(255,255,255,0.13)',
        duration: 0.3,
        overwrite: true
      });
    };
    fileInput.addEventListener('focus', handleFocus);
    fileInput.addEventListener('blur', handleBlur);
    return () => {
      fileInput.removeEventListener('focus', handleFocus);
      fileInput.removeEventListener('blur', handleBlur);
    };
  }, []);

  // Minimalistic GSAP.com-inspired UI
  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-10"
      style={{
        background:
          'radial-gradient(ellipse at 60% 25%, #1e293b 60%, #0f172a 100%)'
      }}>
      <div
        ref={formRef}
        className="w-full max-w-lg mx-auto flex flex-col items-center justify-center rounded-3xl shadow-lg bg-white bg-opacity-5 backdrop-blur-2xl px-8 py-10"
        style={{
          boxShadow:
            '0 6px 32px 0 rgba(0,0,0,0.28), 0 0.5px 1.5px 0 rgba(0,255,153,0.03)'
        }}
      >
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-2 tracking-tight text-center"
          style={{
            letterSpacing: '-0.03em'
          }}
        >
          <span className="inline-block align-middle mr-2">
            <svg className="w-7 h-7 text-green-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" stroke="currentColor" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 13l3 3 5-5" />
            </svg>
          </span>
          Add a Comment
        </h2>
        <div className="text-gray-300 text-base mb-6 text-center opacity-80">
          Share your thoughts with the community. Feedback is always welcome!
        </div>
        <div className="flex items-center mb-6">
          <div className="w-8 h-8 rounded-full bg-green-500 bg-opacity-30 flex items-center justify-center text-white font-bold text-lg mr-3 select-none">
            {user?.charAt(0)?.toUpperCase()}
          </div>
          <span className="text-gray-300 text-sm">
            Posting as: <span className="font-medium text-white">{anonymous ? 'Anonymous' : user}</span>
          </span>
        </div>
        {success && (
          <div
            ref={successRef}
            className="w-full flex items-center justify-center bg-green-500 bg-opacity-10 text-green-300 font-medium px-4 py-2 rounded-full mb-5 text-sm"
          >
            <svg className="w-5 h-5 mr-2 text-green-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" stroke="currentColor" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 13l3 3 5-5" />
            </svg>
            Comment posted successfully!
          </div>
        )}
        <form className="w-full" onSubmit={handleSubmit} autoComplete="off">
          <div className="mb-7">
            <textarea
              ref={contentInputRef}
              id="content"
              value={content}
              onChange={e => setContent(e.target.value)}
              className="w-full resize-none bg-transparent border-0 border-b-2 border-white border-opacity-20 focus:border-green-400 focus:outline-none text-white text-base px-0 py-2 transition-all duration-200 placeholder-gray-400 placeholder-opacity-80"
              rows={4}
              placeholder="Share your thoughts..."
              required
              spellCheck={true}
              maxLength={2000}
              style={{
                transition: 'box-shadow .2s, border-color .2s'
              }}
            />
          </div>
          <div className="mb-7">
            <label className="block text-gray-400 text-xs font-medium mb-2 tracking-wider uppercase">
              Image (optional)
            </label>
            <div
              className="relative group flex items-center rounded-2xl border-2 border-dashed border-white border-opacity-10 py-4 px-6 hover:border-green-400 transition-colors duration-200"
              style={{ minHeight: '64px' }}
            >
              <input
                ref={fileInputRef}
                type="file"
                id="media"
                accept="image/*"
                onChange={e => setMedia(e.target.files[0])}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                tabIndex={0}
              />
              {!preview && (
                <div className="flex flex-col items-center w-full pointer-events-none">
                  <svg className="w-7 h-7 mb-1 text-gray-400 group-hover:text-green-400 transition-colors" fill="none" stroke="currentColor" strokeWidth="1.7" viewBox="0 0 24 24">
                    <rect x="4" y="4" width="16" height="16" rx="3" stroke="currentColor" />
                    <path d="M8 16l3-4 2.5 3L17 12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  <span className="text-gray-400 text-xs font-medium">
                    {media ? media.name : 'Click or drag to upload image'}
                  </span>
                </div>
              )}
              {preview && (
                <div
                  ref={previewRef}
                  className="absolute inset-0 flex items-center justify-center file-preview"
                  style={{ background: 'rgba(15,23,42,0.82)' }}
                >
                  <div className="relative w-full max-h-40 flex flex-col items-end">
                    <img
                      src={preview}
                      alt="Preview"
                      className="rounded-xl w-full object-contain max-h-40 shadow-lg"
                      style={{ border: '1.5px solid rgba(255,255,255,0.10)' }}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (previewRef.current) {
                          gsap.to(previewRef.current, {
                            opacity: 0,
                            scale: 0.93,
                            duration: 0.3,
                            onComplete: () => {
                              setMedia(null);
                              setPreview(null);
                            }
                          });
                        } else {
                          setMedia(null);
                          setPreview(null);
                        }
                      }}
                      className="absolute top-2 right-2 bg-black bg-opacity-50 text-white rounded-full p-1 hover:bg-opacity-80 transition-all duration-200 z-10"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                        <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeLinecap="round"/>
                        <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeLinecap="round"/>
                      </svg>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center mb-7">
            <label className="flex items-center cursor-pointer select-none">
              <input
                type="checkbox"
                checked={anonymous}
                onChange={e => setAnonymous(e.target.checked)}
                className="form-checkbox rounded-full h-4 w-4 text-green-400 focus:ring-0 border-white border-opacity-20 bg-transparent"
                style={{
                  accentColor: '#22d3ee'
                }}
              />
              <span className="ml-2 text-gray-300 text-sm">Comment anonymously</span>
            </label>
          </div>
          {error && (
            <div className="w-full flex items-center justify-center bg-red-500 bg-opacity-10 text-red-300 font-medium px-4 py-2 rounded-full mb-5 text-sm">
              <svg className="w-5 h-5 mr-2 text-red-300" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke="currentColor" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 11h8M12 7v8" />
              </svg>
              {error}
            </div>
          )}
          <button
            ref={btnRef}
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center px-8 py-3 rounded-full bg-gradient-to-r from-green-400 via-green-500 to-teal-400 text-white font-semibold text-lg shadow-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 hover:from-green-500 hover:to-teal-500 active:scale-95"
            style={{
              boxShadow:
                '0 4px 18px 0 rgba(34,197,94,0.13), 0 1.5px 4px 0 rgba(0,0,0,0.03)'
            }}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Posting...
              </>
            ) : (
              <>
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7 17l9.2-5.2c.8-.4.8-1.6 0-2L7 5M7 5v12" />
                </svg>
                Post Comment
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}

export default PostForm;