
   import { useState } from 'react';
   import { useDispatch, useSelector } from 'react-redux';
   import { useNavigate } from 'react-router-dom';
   import { register } from '../store/authSlice';

   function RegisterPage() {
     const [username, setUsername] = useState('');
     const [password, setPassword] = useState('');
     const dispatch = useDispatch();
     const navigate = useNavigate();
     const { loading, error } = useSelector((state) => state.auth);

     const handleSubmit = (e) => {
       e.preventDefault();
       dispatch(register({ username, password })).then((result) => {
         if (result.meta.requestStatus === 'fulfilled') {
           navigate('/login');
         }
       });
     };

     return (
       <div className="max-w-md mx-auto">
         <h1 className="text-3xl font-bold mb-4">Register</h1>
         <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
           <div className="mb-4">
             <label htmlFor="username" className="block text-sm font-medium text-gray-700">
               Username
             </label>
             <input
               type="text"
               id="username"
               value={username}
               onChange={(e) => setUsername(e.target.value)}
               className="mt-1 p-2 w-full border rounded-md"
               required
             />
           </div>
           <div className="mb-4">
             <label htmlFor="password" className="block text-sm font-medium text-gray-700">
               Password
             </label>
             <input
               type="password"
               id="password"
               value={password}
               onChange={(e) => setPassword(e.target.value)}
               className="mt-1 p-2 w-full border rounded-md"
               required
             />
           </div>
           {error && <p className="text-red-500 mb-4">{error}</p>}
           <button
             type="submit"
             disabled={loading}
             className="w-full bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 disabled:bg-blue-300"
           >
             {loading ? 'Registering...' : 'Register'}
           </button>
         </form>
       </div>
     );
   }

   export default RegisterPage;
