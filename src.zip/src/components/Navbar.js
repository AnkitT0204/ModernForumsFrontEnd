// import { Link, useNavigate } from 'react-router-dom';
// import { useSelector, useDispatch } from 'react-redux';
// import { logout } from '../store/authSlice';
// import { useTheme } from '../context/ThemeContext';

// function Navbar() {
//   const { user, role } = useSelector((state) => state.auth);
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const { theme, toggleTheme } = useTheme();

//   const handleLogout = () => {
//     dispatch(logout());
//     navigate('/');
//   };

//   return (
//     <nav>
//       <div className="container mx-auto flex justify-between items-center h-full">
//         <Link to="/" className="text-2xl font-bold flex items-center">
//           <span className="text-[var(--accent-primary)]">Chan</span>
//           <span className="text-xs ml-1 font-normal rounded-md bg-[var(--accent-primary)] text-white px-2 py-0.5">
//             beta
//           </span>
//         </Link>
        
//         <div className="flex items-center space-x-6">
//           <Link to="/boards" className="hover:text-[var(--accent-primary)] font-medium transition-colors">
//             Boards
//           </Link>
          
//           <div className="relative">
//             <select
//               value={theme}
//               onChange={(e) => toggleTheme(e.target.value)}
//               className="theme-selector"
//               aria-label="Select theme"
//             >
//               <option value="light-gray">Light Mode</option>
//               <option value="dark-blue">Dark Blue</option>
//               <option value="neon-black">Neon Black</option>
//             </select>
//           </div>
          
//           {user ? (
//             <div className="flex items-center space-x-4">
//               <div className="hidden md:block">
//                 <span className="px-3 py-1 rounded-full bg-[var(--bg-primary)] text-[var(--text-secondary)] text-sm">
//                   {user} {role && <span className="text-xs opacity-60">({role})</span>}
//                 </span>
//               </div>
//               <button 
//                 onClick={handleLogout} 
//                 className="text-sm hover:text-[var(--accent-primary)] transition-colors"
//               >
//                 Logout
//               </button>
//             </div>
//           ) : (
//             <div className="flex items-center space-x-2">
//               <Link 
//                 to="/login" 
//                 className="px-3 py-1.5 text-sm hover:text-[var(--accent-primary)] transition-colors"
//               >
//                 Login
//               </Link>
//               <Link 
//                 to="/register"
//                 className="px-4 py-1.5 text-sm bg-[var(--accent-primary)] text-white rounded-md hover:bg-[var(--accent-hover)] transition-colors"
//               >
//                 Sign Up
//               </Link>
//             </div>
//           )}
//         </div>
//       </div>
//     </nav>
//   );
// }

// export default Navbar;

import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useEffect, useRef } from 'react';
import { logout } from '../store/authSlice';
import { useTheme } from '../context/ThemeContext';
import gsap from 'gsap';

function Navbar() {
  const { user, role } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  
  const navbarRef = useRef(null);
  const logoRef = useRef(null);
  const navItemsRef = useRef(null);
  
  useEffect(() => {
    // Logo animation
    gsap.from(logoRef.current, {
      opacity: 0,
      x: -20,
      duration: 0.8,
      ease: "power3.out"
    });
    
    // Navbar items staggered animation
    gsap.from(navItemsRef.current.children, {
      opacity: 0,
      y: -15,
      duration: 0.6,
      stagger: 0.1,
      ease: "back.out(1.4)"
    });
    
    // Navbar background
    gsap.from(navbarRef.current, {
      backgroundPosition: "0% 100%",
      duration: 1.2,
      ease: "power2.out"
    });
  }, []);

  const handleLogout = () => {
    gsap.to(navItemsRef.current.children, {
      opacity: 0,
      y: -10,
      duration: 0.3,
      stagger: 0.05,
      onComplete: () => {
        dispatch(logout());
        navigate('/');
      }
    });
  };

  return (
    <nav 
      ref={navbarRef}
      className="bg-[var(--bg-secondary)] text-[var(--text-primary)] py-4 shadow-lg backdrop-blur-md sticky top-0 z-50 border-b border-opacity-10"
    >
      <div className="container mx-auto flex justify-between items-center px-6">
        <Link to="/" className="font-bold text-2xl tracking-tight relative" ref={logoRef}>
          <span className="text-[var(--accent-primary)]">Chan</span>
          <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[var(--accent-primary)] opacity-0 group-hover:w-full group-hover:opacity-100 transition-all duration-300"></span>
        </Link>
        
        <div className="flex items-center space-x-6" ref={navItemsRef}>
          <Link 
            to="/boards" 
            className="relative overflow-hidden group py-2"
          >
            <span className="relative z-10">Boards</span>
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent-primary)] group-hover:w-full transition-all duration-300"></span>
          </Link>
          
          {user ? (
            <>
              <div className="text-sm bg-[var(--bg-primary)] py-1 px-3 rounded-full">
                <span className="font-medium">{user}</span>
                <span className="opacity-60 ml-1">({role})</span>
              </div>
              
              <button 
                onClick={handleLogout} 
                className="relative overflow-hidden group py-2"
              >
                <span className="relative z-10">Logout</span>
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent-primary)] group-hover:w-full transition-all duration-300"></span>
              </button>
            </>
          ) : (
            <>
              <Link 
                to="/login" 
                className="relative overflow-hidden group py-2"
              >
                <span className="relative z-10">Login</span>
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent-primary)] group-hover:w-full transition-all duration-300"></span>
              </Link>
              
              <Link 
                to="/register" 
                className="bg-[var(--accent-primary)] text-white py-2 px-4 rounded-lg hover:bg-[var(--accent-hover)] transition-all duration-200 transform hover:-translate-y-0.5"
              >
                Register
              </Link>
            </>
          )}
          
          <select
            value={theme}
            onChange={(e) => toggleTheme(e.target.value)}
            className="bg-[var(--bg-secondary)] text-[var(--text-primary)] border border-opacity-10 rounded-lg py-2 pl-3 pr-8 cursor-pointer hover:border-[var(--accent-primary)] transition-colors duration-200"
          >
            <option value="neon-black">Neon Black</option>
            <option value="dark-blue">Dark Blue</option>
            <option value="light-gray">Light Gray</option>
          </select>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;