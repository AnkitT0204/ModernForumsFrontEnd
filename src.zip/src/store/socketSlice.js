import { createSlice } from '@reduxjs/toolkit';
import { io } from 'socket.io-client';

const socket = io('http://localhost:5001', { autoConnect: false });

const socketSlice = createSlice({
  name: 'socket',
  initialState: {
    socket,
    newPosts: [],
    deletedPosts: [],
    isConnected: false,
  },
  reducers: {
    connectSocket: (state) => {
      if (!state.isConnected) {
        state.socket.connect();
        state.isConnected = true;
        console.log('Socket connected');
      }
    },
    disconnectSocket: (state) => {
      state.socket.disconnect();
      state.isConnected = false;
      console.log('Socket disconnected');
    },
    addNewPost: (state, action) => {
      console.log('Adding new post:', action.payload);
      state.newPosts.push(action.payload);
    },
    addDeletedPost: (state, action) => {
      console.log('Adding deleted post:', action.payload);
      state.deletedPosts.push(action.payload);
    },
    clearNewPosts: (state) => {
      state.newPosts = [];
    },
    clearDeletedPosts: (state) => {
      state.deletedPosts = [];
    },
  },
});

export const { connectSocket, disconnectSocket, addNewPost, addDeletedPost, clearNewPosts, clearDeletedPosts } = socketSlice.actions;
export default socketSlice.reducer;